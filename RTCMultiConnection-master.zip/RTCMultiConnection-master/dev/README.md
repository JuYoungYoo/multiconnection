# RTCMultiConnection Development files

These are small pieces of JavaScript files that are used to generate `RTCMultiConnection.js`!!!

# For contributions, you have to modify these files

Then use `grunt` to compile `RTCMultiConnection.js` again.
